----------------------------------------------------------------------------------------------
-- vw_ddl_object
----------------------------------------------------------------------------------------------
drop view if exists normal.vw_ddl_object;
create or replace view normal.vw_ddl_object
as select o.vw_reg_cdm_id as obj_id,
    o.vw_reg_cdm_code as obj_code,
    o.vw_reg_cdm_name as obj_name,
    o.vw_reg_cdm_descr as obj_descr,
    o.view_register_mat_kind_id as obj_type_id,
    'cdm' as obj_schema,
    null as ods_obj_bucket_s3,
    null as ods_obj_schema
   from normal.view_register_cdm o
  where (o.vw_reg_cdm_id in ( select s.vw_reg_cdm_id
           from normal.view_structure_cdm s))
union all
 select o.vw_reg_bdm_id as obj_id,
    o.vw_reg_bdm_code as obj_code,
    o.vw_reg_bdm_name as obj_name,
    o.vw_reg_bdm_descr as obj_descr,
    o.view_register_mat_kind_id as obj_type_id,
    'bdm' as obj_schema,
    null as ods_obj_bucket_s3,
    null as ods_obj_schema
   from normal.view_register_bdm o
  where (o.vw_reg_bdm_id in ( select s.vw_reg_bdm_id
           from normal.view_structure_bdm s))
union all
 select o.dds_obj_id as obj_id,
    o.dds_obj_code as obj_code,
    o.dds_obj_name as obj_name,
    null as obj_descr,
    o.dds_obj_type_id as obj_type_id,
    'dds' as obj_schema,
    null as ods_obj_bucket_s3,
    null as ods_obj_schema
   from normal.dds_object o
  where (o.dds_obj_id in ( select s.dds_obj_id
           from normal.dds_structure s))
union all
 select o.ods_obj_id as obj_id,
    o.ods_obj_code as obj_code,
    o.ods_obj_name as obj_name,
    null as obj_descr,
    o.src_sys_obj_type_id as obj_type_id,
    'ods' as obj_schema,
    ( select bc.bckt_s3_name
           from normal.bucket_s3 bc
          where bc.bckt_s3_id = i.bckt_s3_id) as ods_obj_bucket_s3,
    ( select sch.int_sch_name
           from normal.integration_scheme sch
          where sch.int_sch_id = i.int_sch_id) as ods_obj_schema
   from normal.ods_object o,
    normal.integration_protocol i
  where (o.ods_obj_id in ( select s.ods_obj_id
           from normal.ods_structure s)) and o.int_prt_id = i.int_prt_id
-- EDM
union all
 select o.edm_idx_reg_id as obj_id,
    o.edm_idx_reg_code as obj_code,
    o.edm_idx_reg_name as obj_name,
    o.edm_idx_reg_descr as obj_descr,
    normal.pk_format('ТАБЛИЦА') as obj_type_id,
    'edm' as obj_schema,
    null as ods_obj_bucket_s3,
    null as ods_obj_schema
   from normal.edm_index_register o;
----------------------------------------------------------------------------------------------
-- vw_ddl_object_type
----------------------------------------------------------------------------------------------
drop view if exists normal.vw_ddl_object_type;
create or replace view normal.vw_ddl_object_type
as select m.view_register_mat_kind_name as obj_type_name,
    m.view_register_mat_kind_id as obj_type_id,
    'cdm' as obj_schema,
    '' as prefix,
    '' as postfix
   from normal.view_register_mat_kind m
  where upper(m.view_register_mat_kind_name) = 'ТАБЛИЦА'
union all
 select m.view_register_mat_kind_name as obj_type_name,
    m.view_register_mat_kind_id as obj_type_id,
    'bdm' as obj_schema,
    '' as prefix,
    '' as postfix
   from normal.view_register_mat_kind m
  where upper(m.view_register_mat_kind_name) = 'ТАБЛИЦА'
union all
 select m.dds_obj_type_name as obj_type_name,
    m.dds_obj_type_id as obj_type_id,
    'dds' as obj_schema,
        case
            when upper(m.dds_obj_type_name) = 'LINK' then 'lk_'
            when upper(m.dds_obj_type_name) = 'SATELLITE' then 'st_'
            when upper(m.dds_obj_type_name) = 'HUB' then 'hub_'
            when upper(m.dds_obj_type_name) = 'DICTIONARY' then 'dct_'
            when upper(m.dds_obj_type_name) = 'ATTRIBUTE' then 'atr_'
            else ''
        end as prefix,
    '' as postfix
   from normal.dds_object_type m
union all
 select m.src_sys_obj_type_name as obj_type_name,
    m.src_sys_obj_type_id as obj_type_id,
    'ods' as obj_schema,
    '' as prefix,
    '_i_ext' as postfix
   from normal.source_system_object_type m
  where upper(m.src_sys_obj_type_name) = 'ТАБЛИЦА'
union all
 select m.src_sys_obj_type_name as obj_type_name,
    m.src_sys_obj_type_id as obj_type_id,
    'ods' as obj_schema,
    '' as prefix,
    '_h_ext' as postfix
   from normal.source_system_object_type m
  where upper(m.src_sys_obj_type_name) = 'ТАБЛИЦА'
union all
 select m.src_sys_obj_type_name as obj_type_name,
    m.src_sys_obj_type_id as obj_type_id,
    'ods' as obj_schema,
    '' as prefix,
    '_i' as postfix
   from normal.source_system_object_type m
  where upper(m.src_sys_obj_type_name) = 'ТАБЛИЦА'
-- EDM  
union all
 select 'ТАБЛИЦА' as obj_type_name,
    normal.pk_format('ТАБЛИЦА') as obj_type_id,
    'edm' as obj_schema,
    '' as prefix,
    '' as postfix;
----------------------------------------------------------------------------------------------
-- vw_ddl_structure
----------------------------------------------------------------------------------------------
drop view if exists normal.vw_ddl_structure;
create or replace view normal.vw_ddl_structure
( obj_str_id
, obj_id
, obj_str_attr
, obj_str_attr_name
, obj_str_data_type
, obj_str_precision
, obj_str_not_null
, obj_str_link_obj
, obj_str_expl	
, obj_schema
, ods_obj_schema	
)
as 
select m.vw_str_cdm_id as obj_str_id
	 , m.vw_reg_cdm_id as obj_id
	 , m.vw_str_cdm_attr as obj_str_attr
	 , m.vw_str_cdm_attr_name as obj_str_attr_name
	 , m.str_data_type_id as obj_str_data_type
	 , m.vw_str_cdm_precision as obj_str_precision
	 , m.yes_no_id as obj_str_not_null
	 , m.vw_str_cdm_link_obj as obj_str_link_obj
	 , m.vw_str_cdm_expl as obj_str_expl	
	 , 'cdm' as obj_schema
	 , null as ods_obj_schema	
 from normal.view_structure_cdm m
union all	
select m.vw_str_bdm_id as obj_str_id
	 , m.vw_reg_bdm_id as obj_id
	 , m.vw_str_bdm_attr as obj_str_attr
	 , m.vw_str_bdm_attr_name as obj_str_attr_name
	 , m.str_data_type_id as obj_str_data_type
	 , m.vw_str_bdm_precision as obj_str_precision
	 , m.yes_no_id as obj_str_not_null
	 , m.vw_str_bdm_link_obj as obj_str_link_obj
	 , m.vw_str_bdm_expl as obj_str_expl	
	 , 'bdm' as obj_schema
	 , null as ods_obj_schema	
 from normal.view_structure_bdm m
-- DDS 
union all	
select m.dds_str_id as obj_str_id
	 , m.dds_obj_id as obj_id
	 , m.dds_str_attr as obj_str_attr
	 , m.dds_str_descr as obj_str_attr_name
	 , m.str_data_type_id as obj_str_data_type
	 , m.dds_str_precision as obj_str_precision
	 , null as obj_str_not_null
	 , null as obj_str_link_obj
	 , null as obj_str_expl	
	 , 'dds' as obj_schema
	 , null as ods_obj_schema	
 from normal.dds_structure m
-- ODS 
union all	
 select m.ods_str_id as obj_str_id
	 , m.ods_obj_id as obj_id
	 , m.ods_str_attr as obj_str_attr
	 , m.ods_str_descr as obj_str_attr_name
	 , m.str_data_type_id as obj_str_data_type
	 , m.ods_str_precision as obj_str_precision
	 , null as obj_str_not_null
	 , null as obj_str_link_obj
	 , null as obj_str_expl	
	 , 'ods' as obj_schema
     , ( select sch.int_sch_name
           from normal.integration_scheme sch
          where sch.int_sch_id = i.int_sch_id) as ods_obj_schema	 
 from normal.ods_structure m,
    normal.integration_protocol i
union all	
select normal.pk_format(edm_idx_reg_code || s.edm_idx_str_synt_attr) as obj_str_id
	 , m.edm_idx_reg_id as obj_id
	 , s.edm_idx_str_synt_attr  as obj_str_attr
	 , s.edm_idx_str_synt_attr_name  as obj_str_attr_name
	 , s.str_data_type_id as obj_str_data_type
	 , s.edm_idx_str_synt_precision  as obj_str_precision
	 , s.yes_no_id as obj_str_not_null
	 , null as obj_str_link_obj
	 , null as obj_str_expl	
	 , 'edm' as obj_schema
	 , null as ods_obj_schema	
 from normal.edm_index_register m,
  	  normal.edm_index_structure_synt s; 
 