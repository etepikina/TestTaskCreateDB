-- попытка создать в GP  
select count(*)
from normal.object_ddl_log l
where l.process_ts >  '2023-11-15 10:19:000'::timestamp ;  

select process_ts, object_name, table_name, table_ddl, status, error_msg
from normal.object_ddl_log l
where l.process_ts > '2023-11-15 10:19:000'::timestamp  -- CURRENT_DATE
order by process_ts desc;

select process_ts, object_name, table_name, table_ddl, status, error_msg
from normal.object_ddl_log l
where l.process_ts > '2023-10-20 15:00:000'::timestamp
and l.status = 'error';
---------------------------   
--   CDM
---------------------------   
--создано в GP  236
select count(*)
  from information_schema.tables
 where table_schema = 'cdm';	

-- описано в meta  68
select count(*)
from normal.view_register_cdm o
where o.vw_reg_cdm_id 
   in (select s.vw_reg_cdm_id from normal.view_structure_cdm s);  -- описаны столбцы
---------------------------   
--   BDM
---------------------------   
--создано в GP  
select count(*)
  from information_schema.tables
 where table_schema = 'bdm';	

-- описано в meta  
select count(*)
from normal.view_register_bdm o
where o.vw_reg_bdm_id 
   in (select s.vw_reg_bdm_id from normal.view_structure_bdm s);  -- описаны столбцы     
---------------------------   
--   DDS
---------------------------     
--создано в GP  236
select count(*)
  from information_schema.tables
 where table_schema = 'dds';	

-- описано в meta  249
select count(*)
from normal.dds_object o
where o.dds_obj_id 
   in (select s.dds_obj_id from normal.dds_structure s);  -- описаны столбцы
   