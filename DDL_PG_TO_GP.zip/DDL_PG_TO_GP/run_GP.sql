----------------------------------------------
--     CDM
----------------------------------------------
SELECT 'DO 
$crt_ods$
begin
'
||string_agg (table_ddl,'')||'
end
$crt_ods$;'
FROM normal.CDM_ddl_greenplum_tbl t
----------------------------------------------
SELECT string_agg (table_ddl,'')
FROM normal.CDM_ddl_greenplum_tbl t



----------------------------------------------
-- GP
select metastore.create_objects(null,null);
-- select metastore.create_objects('cdm',null);
-- --select metastore.create_objects( null, null );