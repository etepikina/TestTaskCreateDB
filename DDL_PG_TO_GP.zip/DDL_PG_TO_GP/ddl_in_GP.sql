-- CREATE SCHEMA IF NOT EXISTS cdm;
-- CREATE SCHEMA IF NOT EXISTS edm;
-- CREATE SCHEMA IF NOT EXISTS bdm;
-- CREATE SCHEMA IF NOT EXISTS dds;
-- GP
DROP EXTERNAL TABLE metastore.object_ddl_log;
CREATE WRITABLE EXTERNAL TABLE askd.metastore.object_ddl_log (
	process_ts      timestamp,
	object_name     varchar,
	schema_name     varchar,
	table_name      varchar,
	table_ddl       varchar,
	status          varchar,
	error_msg       varchar
)
LOCATION ('pxf://normal.object_ddl_log?PROFILE=jdbc&SERVER=pg') 
FORMAT 'CUSTOM' ( FORMATTER='pxfwritable_export' );
--
-- GP( смотрит на вью в мета)
DROP EXTERNAL TABLE metastore.ddl_greenplum_tbl;
CREATE EXTERNAL TABLE askd.metastore.ddl_greenplum_tbl (
	object_name  varchar,
	schema_name  varchar,	
	table_name   varchar,
	table_ddl    varchar
)
LOCATION ('pxf://normal.ddl_greenplum_tbl?PROFILE=jdbc&SERVER=pg') 
FORMAT 'CUSTOM' ( FORMATTER='pxfwritable_import' );
--
-----------------------------------------------------------------------
--
-----------------------------------------------------------------------
create or replace function metastore.create_objects(p_schema_name in varchar(100), p_table_name in varchar(100))
	returns void
	language plpgsql
	volatile
as $$
	
 declare
 
 	v_schema_list  text := '!!!SCHEMA LIST'; -- Создаем схемы, если нет
	v_ddl_stmt     varchar;
	v_process_id   timestamp;
	v_error_msg    varchar;
	tbl            record;
	err_code       text;
	msg_text       text;
	exc_context    text;
	msg_detail     text;
	exc_hint       text;

begin	  
	
	select current_timestamp::timestamp into v_process_id;
	-- RAISE INFO 'p_schema_name: %  p_table_name: %', p_schema_name, p_table_name;	

    for tbl in (select object_name, schema_name, table_name, table_ddl from metastore.ddl_greenplum_tbl t
    		     where ( upper(coalesce ( p_schema_name, t.schema_name)) =  upper(t.schema_name) )
  				   and ( upper(coalesce ( p_table_name, t.table_name)) =  upper(t.table_name) 
  				         or upper(coalesce ( t.table_name )) =  v_schema_list)   				 
  				 order by t.table_name asc)   
	loop	
		--RAISE INFO 'tbl.table_ddl: %  p_table_name: %', tbl.table_ddl, tbl.table_name;				
    	begin
			execute (tbl.table_ddl);
		
			-- RAISE INFO 'v_process_id: %  object_name: %', v_process_id, tbl.object_name;		
			insert into metastore.object_ddl_log values (v_process_id, tbl.object_name, tbl.schema_name, tbl.table_name, tbl.table_ddl, 'ok', '');
		EXCEPTION WHEN OTHERS  
		THEN
			GET STACKED DIAGNOSTICS
	    	err_code = RETURNED_SQLSTATE, 		-- код ошибки
			msg_text = MESSAGE_TEXT, 			-- текст ошибки
	    	exc_context = PG_CONTEXT, 			-- контекст исключения
	 		msg_detail = PG_EXCEPTION_DETAIL, 	-- подробный текст ошибки
	 		exc_hint = PG_EXCEPTION_HINT; 		-- текст подсказки к исключению
			v_error_msg := format('ERROR CODE: %s MESSAGE TEXT: %s CONTEXT: %s DETAIL: %s HINT: %s', 
									err_code, msg_text, exc_context, msg_detail, exc_hint);
	    	--RAISE NOTICE v_error_msg;
	   		
			--v_error_msg:=format('ERROR CODE: %s . MESSAGE TEXT: %s', SQLSTATE, sqlerrm);
			--RAISE NOTICE 'ERROR CODE: %s . MESSAGE TEXT: %s', SQLSTATE, SQLERRM;
			insert into metastore.object_ddl_log values (v_process_id, tbl.object_name, tbl.schema_name, tbl.table_name, tbl.table_ddl, 'error'::varchar, v_error_msg);
		end;
    end loop;
end

$$
EXECUTE ON ANY;
----------------------------------------------------------------------- 
-- select metastore.create_objects();
