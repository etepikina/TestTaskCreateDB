-----------------------------------------------------------------------
-- drop function if exists normal.ddl_greenplum_tbl;
create or replace function normal.ddl_greenplum_tbl()
 returns table(object_name character varying, schema_name character varying, table_name character varying, table_ddl character varying)
 language plpgsql
as $ddl$
 declare
 
    start_tab		 RECORD;
    tab 			 RECORD;
    col 			 RECORD;
   
	v_comma          VARCHAR := ' ';

	postgres_max_id  INTEGER := 63;

	v_table_str 	 VARCHAR := '';
	v_comment_str 	 VARCHAR := '';

	v_schema		 VARCHAR := '';
	-- Внешние таблицы
	v_ods 			 VARCHAR := 'ods';
	v_env_bucket 	 VARCHAR := '';
	v_external_str   VARCHAR := '
)
LOCATION (''pxf://%s/%s/%s/%s/%s.parquet?PROFILE=s3:parquet&SERVER=myminio'')
FORMAT ''CUSTOM'' (FORMATTER=''pxfwritable_import''';
	v_ods_increment  VARCHAR := 'increment_data';
	v_ods_history    VARCHAR := 'history_data';	
	
begin	  	

	create TEMP TABLE table_ddls (
	  object_name   varchar,
	  schema_name   varchar,
   	  table_name    varchar,
 	  table_ddl     varchar
	) on commit drop;
	 
	-- создание схем при запуске для всех <<
    select string_agg('CREATE SCHEMA IF NOT EXISTS '||sch.int_sch_name ||';', '
' ) 
	  into v_schema
	  from normal.integration_scheme sch;  
	insert into table_ddls values ('SCHEMA', 'ods', '!!!SCHEMA LIST', v_schema);	 
	-- 
	insert into table_ddls values ('SCHEMA', 'dds', '!!!SCHEMA LIST', 'CREATE SCHEMA IF NOT EXISTS dds;') ;	
	insert into table_ddls values ('SCHEMA', 'cdm', '!!!SCHEMA LIST', 'CREATE SCHEMA IF NOT EXISTS cdm;') ;	
	insert into table_ddls values ('SCHEMA', 'bdm', '!!!SCHEMA LIST', 'CREATE SCHEMA IF NOT EXISTS bdm;') ;
	insert into table_ddls values ('SCHEMA', 'edm', '!!!SCHEMA LIST', 'CREATE SCHEMA IF NOT EXISTS edm;') ;
	-- >> создание схем 

								  
	for start_tab in ( select d.obj_type_id
							, d.obj_schema
							, d.prefix
							, d.postfix
							, upper(d.obj_type_name) as obj_type_name
							from normal.vw_ddl_object_type d )
	loop		
		-- RAISE INFO 'obj_type_name := % obj_schema = % ', start_tab.obj_type_name, start_tab.obj_schema;
		v_table_str := v_table_str||format( '
-- START %s ', start_tab );	

		for tab in select o.* 
						, regexp_replace(o.obj_name, E'[\\r\\n]', ' ','g') as parse_table_name 
						, coalesce( o.ods_obj_schema, o.obj_schema ) ||'.'        --- ODS
						       ||start_tab.prefix
						       ||left(o.obj_code, postgres_max_id - length(start_tab.prefix)- length(start_tab.postfix))
						       ||start_tab.postfix as sch_obj_code
						, replace(o.obj_code,' ','') as table_name
					 from normal.vw_ddl_object o
					where o.obj_type_id  = start_tab.obj_type_id	
					  and o.obj_schema = start_tab.obj_schema	
					  --and o.vw_reg_id = '9814d942-b7e2-4870-084a-3dce24867ab3'::uuid
		loop    
		
		   	v_table_str := '';			
			-- внешние для ODS
			if start_tab.postfix in ('_i_ext', '_h_ext') then 
				v_table_str := v_table_str || format( '
-- %s
DROP EXTERNAL TABLE IF EXISTS %s;
CREATE EXTERNAL TABLE %s ( ', tab.parse_table_name
				   , tab.sch_obj_code
				   , tab.sch_obj_code );		    
		    else
				v_table_str := v_table_str || format( '
-- %s
DROP TABLE IF EXISTS %s;
CREATE TABLE %s ( ', tab.parse_table_name
							, tab.sch_obj_code
							, tab.sch_obj_code );
			end if;


			v_comma := ' ';
			v_comment_str := '';
			for col in select s.*
							, regexp_replace(s.obj_str_attr_name, E'[\\r\\n]', ' ','g') as parse_column_descr
							, d.str_data_type_name as parse_data_type_name			
							, case
								  when (s.obj_str_precision IS NOT NULL and upper(d.str_data_type_name) in ('DECIMAL', 'NUMERIC', 'DOUBLE')) 
									then '('||replace(s.obj_str_precision,'.',',')||')'
								  when (s.obj_str_precision IS NOT NULL and upper(d.str_data_type_name) in ('STRING','VARCHAR')) 
									then '('||replace(s.obj_str_precision,'.0','')||')'
								  when (s.obj_str_precision IS NOT NULL and upper(d.str_data_type_name) in ('BOOLEAN', 'DATE', 'INTEGER'))
									then null						
								  else coalesce ('('||s.obj_str_precision||')', '')
							  end as parse_str_precision
							, '"'||left(s.obj_str_attr, postgres_max_id)||'"' as column
						from normal.vw_ddl_structure s, normal.structure_data_type d
						where d.str_data_type_id = s.obj_str_data_type 
						and s.obj_id = tab.obj_id
					  	and (    (s.obj_schema = tab.obj_schema and s.ods_obj_schema is null)
					  		  or s.ods_obj_schema = tab.ods_obj_schema )
			loop       
				v_table_str := v_table_str || format( '
%s %s	%s	%s-- %s', v_comma
					, col.column
					, col.parse_data_type_name
					, col.parse_str_precision
					, col.parse_column_descr);
				-- RAISE INFO 'v_main_ins_str := %', v_main_ins_str;
				v_comma := ','; 
				v_comment_str := v_comment_str||format('
COMMENT ON COLUMN %s.%s IS ''%s'';', tab.sch_obj_code
								   , col.column
								   , col.parse_column_descr 
													  );
				--RAISE INFO 'v_comment_str := %', v_comment_str;
													 
			end loop;

			-- ODS Внешние <<
			if lower (start_tab.obj_schema) = v_ods then			
				-- 
			 	select max(ce.curr_env_bucket_name) 
				  into v_env_bucket
				  from normal.current_environment ce;  			
			
				v_table_str := v_table_str || format( '
, source_system 	VARCHAR 
, load_dttm			TIMESTAMP');			
				-- Внешняя таблица инкремента	
				if start_tab.postfix = '_i_ext' then 
					v_table_str := v_table_str || format( v_external_str, v_env_bucket, v_ods, v_ods_increment, tab.ods_obj_bucket_s3, tab.sch_obj_code );
				-- Внешняя таблица истории
				elsif start_tab.postfix = '_h_ext' then 
					v_table_str := v_table_str || format( v_external_str, v_env_bucket, v_ods, v_ods_history, tab.ods_obj_bucket_s3, tab.sch_obj_code );	
				-- Материализованная таблица инкремента 
				elsif start_tab.postfix = '_i' then 			
					v_table_str := v_table_str || format( '
, import_dttm		TIMESTAMP');
				end if;					
			end if;
			-- ODS Внешние >>
			
			v_table_str := v_table_str || format( '
	);');											
			v_table_str := v_table_str || format( '			
COMMENT ON TABLE %s IS ''%s'';', tab.sch_obj_code, tab.parse_table_name );

			-- COMMENT ON COLUMN
			v_table_str := v_table_str || v_comment_str;
			-- INFO	
			--raise INFO 'v_table_str := %', v_table_str;	
			 insert into table_ddls values (tab.parse_table_name, tab.obj_schema, tab.table_name, v_table_str) ; ---!!!!!!SCHEMA_NAME

		end loop;
	end loop;
	
return query select * from table_ddls;
end
$ddl$;
-- select * from normal.ddl_greenplum_tbl();
-----------------------------------------------------------------------
-- Meta
-- DROP TABLE normal.object_ddl_log;
CREATE TABLE IF NOT EXISTS normal.object_ddl_log (
	process_ts     timestamp   NULL,
	object_name    varchar     NULL,
	schema_name    varchar     NULL,	
	table_name     varchar     NULL,
	table_ddl      varchar     NULL,
	status         varchar(10) NULL,
	error_msg      varchar     NULL
);
-------------------------------------------------------------------------------------------------
-- В Мета
-- normal.ddl_greenplum_tbl source
CREATE OR REPLACE VIEW normal.ddl_greenplum_tbl
AS SELECT ddl_greenplum_tbl.object_name,
		  ddl_greenplum_tbl.schema_name,
		  ddl_greenplum_tbl.table_name,
		  ddl_greenplum_tbl.table_ddl
   FROM normal.ddl_greenplum_tbl() ddl_greenplum_tbl(object_name, schema_name, table_name, table_ddl)
  ORDER BY ddl_greenplum_tbl.schema_name, ddl_greenplum_tbl.table_name;
	